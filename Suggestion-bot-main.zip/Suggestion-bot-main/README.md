<h1 align="center">Suggestions Bot</h1>
<p align="center">
  <img style="border-radius:50%;" width="300" height="300" src="https://e.top4top.io/p_1965qprez1.gif" alt="MeCodes Logo">
</p>
<p align="center">MeCodes Suggestions bot</p>
<p align="center">He and he organizes the suggestions Channels on the servers, where the administrator can specify the suggestions Channels, and people can send the proposal through one of the bot commands, and other than this,<strong> the administrator can simply delete and respond></strong> to the suggestions</p>
<p align="center">The bot needs a <a href="https://www.mongodb.com/">MongoDB </a></p>
<h2>How to use</h2>


*  Go to me-config.json File and put thes info


```json
{
    "prefix": "."
}
```
* Create a  filename .evn and put this info


```env
ME_TOKEN = Bot Token
ME_MONGO = mongodb data url
```


* Run the bot via `node index.js`

