<h1 align="center">BlackList System</h1>
<p align="center">
  <img style="border-radius:50%;" width="300" height="300" src="https://e.top4top.io/p_1965qprez1.gif" alt="MeCodes Logo">
</p>
<p align="center">MeCodes BlackList System</p>
<p align="center">It is a bot that removes the offending member from all servers where the bot is located as a <strong>penalty</strong></p>
<p align="center">The bot needs a <a href="https://www.mongodb.com/">MongoDB </a></p>
<h2>How to use</h2>


*  Go to me-config.json File and put thes info


```json
{
    "__Congig__": "__Prefix__",
    "prefix": ".",
    "___Devlopers_": "__The person__id__who__can__use__the__commands__",
    "dev": ["774303876060676136","","","","","","","","",""]
}
```
* Create a  filename .evn and put this info


```env
ME_TOKEN = Bot Token
ME_MONGO = mongodb data url
```


* Run the bot via `node index.js`


