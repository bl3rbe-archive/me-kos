<h1 align="center">MeCode</h1>
<p align="center">
  <img style="border-radius:50%;" width="300" height="300" src="https://e.top4top.io/p_1965qprez1.gif" alt="MeCodes Logo">
</p>
<p align="center">MeCodes AntiCopyPaster Bot</p>
<p align="center">It is a bot that sends reports about people <strong>stealing their Codes rights</strong> And they say they are programmers etc.</p>
<p align="center">The bot was created in a short period of time,<strong> not exceeding five hours</strong>, and it works with the fastest database system, <strong>MongoDB</strong></p>
<h2>How to use</h2>


*  Go to mecodes-congig.json File and put thes info


```json
{
    "____Bot__Config___": "____Prefix____Report__Channel____",
    "prefix": "BOT_PREFIX",
    "rech": "REPORTS CHANNELS",
    "server": "REPORTS SERVER ID"
}
```
* Create a  filename .evn and put this info


```env
ME_TOKEN = Bot Token
ME_MONGO = mongodb data url
```


* Run the bot via `node index.js`



